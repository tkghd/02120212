// Railway Backend URL
export const API_BASE_URL = 'https://gentle-insight-production-df4a.up.railway.app';

// Fallback to local if Railway is down
export const FALLBACK_URL = 'http://localhost:3000';
