import GlobalDashboard from './components/GlobalDashboard';

export default function App() {
  return <GlobalDashboard />;
}
import TransferHub from './components/TransferHub';
